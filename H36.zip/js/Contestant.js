class Contestant {
  constructor(){
   
  }

  
}
